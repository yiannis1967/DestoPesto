﻿using System;
using Xamarin.Auth;

namespace DestoPesto.Models
{
    public class AuthenticationState
    {
        public static OAuth2Authenticator Authenticator;
    }
}
