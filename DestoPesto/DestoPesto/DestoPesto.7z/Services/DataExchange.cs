﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DestoPesto.Services
{
    /// <MetaDataID>{bf78a29f-c306-4d0d-90bb-8de2799acc77}</MetaDataID>
    public interface DataExchange
    {
        bool GetStatus();
    }
}
