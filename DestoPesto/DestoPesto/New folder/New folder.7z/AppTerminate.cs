﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DestoPesto
{

    public interface ICloseApplication
    {
        void closeApplication();
    }
  
}
