﻿using Xamarin.Forms;

namespace DestoPesto
{
    public interface IBaseUrl { string Get(); }

}