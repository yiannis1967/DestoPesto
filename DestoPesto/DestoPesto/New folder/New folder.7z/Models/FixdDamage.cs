﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DestoPesto.Models
{
    public class FixdDamage
    {
        public string id;
        public string fixedDate;
        public string userId;
    }
}
