﻿using Foundation;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using UIKit;
[assembly: Xamarin.Forms.Dependency(typeof(DestoPesto.IUploadData))]

namespace DestoPesto.iOS
{
    public class UploadData : IUploadData
    {
        public void PostSubmissionWithImage(string url, string submissionjson, Stream image)
        {
            NSUrl nsurl = NSUrl.FromString(url);//"Your url adress");//http://www.apple.com/

            NSMutableUrlRequest request = new NSMutableUrlRequest(nsurl);
            request.HttpMethod = "POST";
            NSMutableDictionary dic = new NSMutableDictionary();
            dic.Add(new NSString("Content-Type"), new NSString("application/json"));
            request.Headers = dic; // add Headers

            request.Body = NSData.FromString("{\"version\":\"v1\", \"cityid\": \"101010100\"}"); //add body

            NSUrlSession session = NSUrlSession.SharedSession;
            NSUrlSessionTask task = session.CreateDataTask(request, (data, response, error) =>
            {
                Console.WriteLine("---"+response);
                Console.WriteLine("---"+ data);
                Console.WriteLine("---"+ error);
            });
            task.Resume();

        }
    }
}