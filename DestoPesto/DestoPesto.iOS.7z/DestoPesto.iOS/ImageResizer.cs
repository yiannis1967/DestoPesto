using System;
using System.IO;
using System.Threading.Tasks;
using Foundation;

#if __IOS__
using System.Drawing;
using UIKit;
using CoreGraphics;
#endif

#if __ANDROID__
using Android.Graphics;
#endif

#if WINDOWS_UWP
using System.Threading.Tasks;
using Windows.Storage.Streams;
using Windows.Graphics.Imaging;
using System.Runtime.InteropServices.WindowsRuntime;
#endif

[assembly: Xamarin.Forms.Dependency(typeof(DestoPesto.Services.ios.ImageResizer))]
namespace DestoPesto.Services.ios
{
    /// <MetaDataID>{3355f2b5-9720-48e2-adf0-d9910dd87c6e}</MetaDataID>
    public class ImageResizer : IImageResizer
    {

      public  Task<byte[]> ResizeImage(byte[] imageData, float width, float height)
        {
#if __IOS__
            return Task.FromResult<byte[]>(ResizeImageIOS(imageData, width, height));
#endif
#if __ANDROID__
			return ResizeImageAndroid ( imageData, width, height );
#endif
#if WINDOWS_UWP
            return await ResizeImageWindows(imageData, width, height);
#endif
        }


#if __IOS__
        public  byte[] ResizeImageIOS(byte[] imageData, float width, float height)
        {
            UIImage originalImage = ImageFromByteArray(imageData);
            UIImageOrientation orientation = originalImage.Orientation;

            //create a 24bit RGB image
            using (CGBitmapContext context = new CGBitmapContext(IntPtr.Zero,
                                                 (int)width, (int)height, 8,
                                                 4 * (int)width, CGColorSpace.CreateDeviceRGB(),
                                                 CGImageAlphaInfo.PremultipliedFirst))
            {

                RectangleF imageRect = new RectangleF(0, 0, width, height);

                // draw the image
                context.DrawImage(imageRect, originalImage.CGImage);

                UIKit.UIImage resizedImage = UIKit.UIImage.FromImage(context.ToImage(), 0, orientation);

                // save the image as a jpeg
                return resizedImage.AsJPEG().ToArray();
            }
        }

        public void Send()
        {
            NSUrl nsurl = NSUrl.FromString("Your url adress");//http://www.apple.com/

            NSMutableUrlRequest request = new NSMutableUrlRequest(nsurl);
            request.HttpMethod = "POST";
            NSMutableDictionary dic = new NSMutableDictionary();
            dic.Add(new NSString("Content-Type"), new NSString("application/json"));
            request.Headers = dic; // add Headers
            
            request.Body = NSData.FromString("{\"version\":\"v1\", \"cityid\": \"101010100\"}"); //add body

            NSUrlSession session = NSUrlSession.SharedSession;
            NSUrlSessionTask task = session.CreateDataTask(request, (data, response, error) =>
            {
                Console.WriteLine("---"+response);
                Console.WriteLine("---"+ data);
                Console.WriteLine("---"+ error);
            });
            task.Resume();
        }



        public static UIKit.UIImage ImageFromByteArray(byte[] data)
        {
            if (data == null)
            {
                return null;
            }

            UIKit.UIImage image;
            try
            {
                image = new UIKit.UIImage(Foundation.NSData.FromArray(data));
            }
            catch (Exception e)
            {
                Console.WriteLine("Image load failed: " + e.Message);
                return null;
            }
            return image;
        }
#endif

#if __ANDROID__
		
		public static byte[] ResizeImageAndroid (byte[] imageData, float width, float height)
		{
			// Load the bitmap
			Bitmap originalImage = BitmapFactory.DecodeByteArray (imageData, 0, imageData.Length);
			Bitmap resizedImage = Bitmap.CreateScaledBitmap(originalImage, (int)width, (int)height, false);

			using (MemoryStream ms = new MemoryStream())
			{
				resizedImage.Compress (Bitmap.CompressFormat.Jpeg, 100, ms);
				return ms.ToArray ();
			}
		}

#endif

#if WINDOWS_UWP

        public static async Task<byte[]> ResizeImageWindows(byte[] imageData, float width, float height)
        {
            byte[] resizedData;

            using (var streamIn = new MemoryStream(imageData))
            {
                using (var imageStream = streamIn.AsRandomAccessStream())
                {
                    var decoder = await BitmapDecoder.CreateAsync(imageStream);
                    var resizedStream = new InMemoryRandomAccessStream();
                    var encoder = await BitmapEncoder.CreateForTranscodingAsync(resizedStream, decoder);
                    encoder.BitmapTransform.InterpolationMode = BitmapInterpolationMode.Linear;
                    encoder.BitmapTransform.ScaledHeight = (uint)height;
                    encoder.BitmapTransform.ScaledWidth = (uint)width;
                    await encoder.FlushAsync();
                    resizedStream.Seek(0);
                    resizedData = new byte[resizedStream.Size];
                    await resizedStream.ReadAsync(resizedData.AsBuffer(), (uint)resizedStream.Size, InputStreamOptions.None);                  
                }                
            }

            return resizedData;
        }

#endif
    }
}

