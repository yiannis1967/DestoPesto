﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DestoPesto.Services
{
    /// <MetaDataID>{26d91a7f-f687-4f5f-a0bb-2bbd4e14f653}</MetaDataID>
    public interface Toast
    {
        void Show(string message);
    }
}
